import{i as a}from"./page-navigation-vWB_GfDR.js";import{o as i,i as s}from"./card-reveal-xSxn4-7-.js";i(()=>{s(".ambassadors-main__card","ambassadors-main__card--visible",140),a()});
