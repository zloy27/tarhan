import{i as a}from"./page-navigation-vWB_GfDR.js";import{o as i,i as r}from"./card-reveal-xSxn4-7-.js";i(()=>{r(".jury-main__card","jury-main__card--visible",140),a()});
